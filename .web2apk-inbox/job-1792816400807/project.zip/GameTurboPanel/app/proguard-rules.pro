# Keep everything for now
-keep class com.gameturbo.panel.** { *; }
