package com.gameturbo.panel

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.gameturbo.panel.databinding.ItemGameBinding

class GameAdapter(
    private val items: MutableList<GameItem>,
    private val onClick: (String) -> Unit
) : RecyclerView.Adapter<GameAdapter.VH>() {

    class VH(val binding: ItemGameBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val binding = ItemGameBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return VH(binding)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val item = items[position]
        holder.binding.ivIcon.setImageDrawable(item.icon)
        holder.binding.tvName.text = item.label
        holder.binding.root.setOnClickListener { onClick(item.packageName) }
    }

    override fun getItemCount() = items.size

    fun update(newList: List<GameItem>) {
        items.clear()
        items.addAll(newList)
        notifyDataSetChanged()
    }
}
