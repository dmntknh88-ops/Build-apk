package com.gameturbo.panel

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import com.gameturbo.panel.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var gameAdapter: GameAdapter
    private val prefs by lazy { getSharedPreferences("gameturbo", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupUI()
        loadGames()
        checkOverlayPermission()
    }

    private fun setupUI() {
        binding.btnStartPanel.setOnClickListener {
            if (Settings.canDrawOverlays(this)) {
                startService(Intent(this, OverlayService::class.java))
                Toast.makeText(this, "Panel aktif", Toast.LENGTH_SHORT).show()
            } else {
                requestOverlayPermission()
            }
        }

        binding.btnStopPanel.setOnClickListener {
            stopService(Intent(this, OverlayService::class.java))
            stopService(Intent(this, CrosshairService::class.java))
            Toast.makeText(this, "Panel dimatikan", Toast.LENGTH_SHORT).show()
        }

        binding.btnAddGame.setOnClickListener {
            startActivity(Intent(this, AddGameActivity::class.java))
        }

        binding.btnCrosshair.setOnClickListener {
            startActivity(Intent(this, CrosshairActivity::class.java))
        }

        binding.btnSettings.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }

        binding.btnSmooth.setOnClickListener {
            toggleSmoothScreen()
        }

        gameAdapter = GameAdapter(mutableListOf()) { pkg ->
            launchGame(pkg)
        }
        binding.rvGames.layoutManager = GridLayoutManager(this, 3)
        binding.rvGames.adapter = gameAdapter
    }

    private fun loadGames() {
        val saved = prefs.getStringSet("games", setOf()) ?: setOf()
        val list = saved.mapNotNull { pkg ->
            try {
                val appInfo = packageManager.getApplicationInfo(pkg, 0)
                val label = packageManager.getApplicationLabel(appInfo).toString()
                val icon = packageManager.getApplicationIcon(pkg)
                GameItem(pkg, label, icon)
            } catch (e: Exception) {
                null
            }
        }.toMutableList()
        gameAdapter.update(list)
    }

    private fun launchGame(packageName: String) {
        val intent = packageManager.getLaunchIntentForPackage(packageName)
        if (intent != null) {
            startActivity(intent)
            if (Settings.canDrawOverlays(this)) {
                startService(Intent(this, OverlayService::class.java))
            }
        } else {
            Toast.makeText(this, "Game tidak ditemukan", Toast.LENGTH_SHORT).show()
        }
    }

    private fun toggleSmoothScreen() {
        val enabled = prefs.getBoolean("smooth_screen", false)
        prefs.edit().putBoolean("smooth_screen", !enabled).apply()
        Toast.makeText(
            this,
            if (!enabled) "Smooth Screen ON" else "Smooth Screen OFF",
            Toast.LENGTH_SHORT
        ).show()
        // Non-root: best effort via settings + accessibility hint
        try {
            Settings.System.putInt(contentResolver, "peak_refresh_rate", if (!enabled) 120 else 60)
        } catch (_: Exception) {}
    }

    private fun checkOverlayPermission() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Izinkan overlay dulu", Toast.LENGTH_LONG).show()
        }
    }

    private fun requestOverlayPermission() {
        val intent = Intent(
            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:$packageName")
        )
        startActivity(intent)
    }

    override fun onResume() {
        super.onResume()
        loadGames()
    }
}
