package com.gameturbo.panel

import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.gameturbo.panel.databinding.ItemAppSelectBinding

class AppSelectAdapter(
    private val apps: List<ApplicationInfo>,
    private val pm: PackageManager,
    private val selected: MutableSet<String>,
    private val onToggle: (String, Boolean) -> Unit
) : RecyclerView.Adapter<AppSelectAdapter.VH>() {

    class VH(val binding: ItemAppSelectBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val b = ItemAppSelectBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return VH(b)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val app = apps[position]
        holder.binding.ivIcon.setImageDrawable(pm.getApplicationIcon(app))
        holder.binding.tvName.text = pm.getApplicationLabel(app)
        holder.binding.tvPkg.text = app.packageName
        holder.binding.cbSelect.isChecked = selected.contains(app.packageName)
        holder.binding.cbSelect.setOnCheckedChangeListener { _, isChecked ->
            onToggle(app.packageName, isChecked)
        }
        holder.binding.root.setOnClickListener {
            holder.binding.cbSelect.isChecked = !holder.binding.cbSelect.isChecked
        }
    }

    override fun getItemCount() = apps.size
}
