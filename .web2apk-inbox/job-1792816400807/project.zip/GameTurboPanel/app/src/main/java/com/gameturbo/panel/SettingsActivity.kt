package com.gameturbo.panel

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.gameturbo.panel.databinding.ActivitySettingsBinding

class SettingsActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySettingsBinding
    private val prefs by lazy { getSharedPreferences("gameturbo", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.swSmooth.isChecked = prefs.getBoolean("smooth_screen", false)
        binding.swShowTouch.isChecked = prefs.getBoolean("show_touch", false)
        binding.swShowCoord.isChecked = prefs.getBoolean("show_coord", false)
        binding.swLockOrient.isChecked = prefs.getBoolean("lock_orient", false)
        binding.swVibrate.isChecked = prefs.getBoolean("vibrate", true)

        binding.swSmooth.setOnCheckedChangeListener { _, c ->
            prefs.edit().putBoolean("smooth_screen", c).apply()
            toast(if (c) "Smooth Screen ON" else "OFF")
        }
        binding.swShowTouch.setOnCheckedChangeListener { _, c ->
            prefs.edit().putBoolean("show_touch", c).apply()
        }
        binding.swShowCoord.setOnCheckedChangeListener { _, c ->
            prefs.edit().putBoolean("show_coord", c).apply()
        }
        binding.swLockOrient.setOnCheckedChangeListener { _, c ->
            prefs.edit().putBoolean("lock_orient", c).apply()
        }
        binding.swVibrate.setOnCheckedChangeListener { _, c ->
            prefs.edit().putBoolean("vibrate", c).apply()
        }

        binding.btnReset.setOnClickListener {
            prefs.edit().clear().apply()
            toast("Reset semua setting")
            finish()
        }
    }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()
}
