package com.gameturbo.panel

import android.app.*
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.*
import android.widget.ImageView
import androidx.core.app.NotificationCompat

class CrosshairService : Service() {

    private lateinit var windowManager: WindowManager
    private var crosshairView: ImageView? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        startForeground(2, buildNotification())
        showCrosshair()
    }

    private fun buildNotification(): Notification {
        val channelId = "gameturbo_crosshair"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId, "Crosshair",
                NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
        return NotificationCompat.Builder(this, channelId)
            .setContentTitle("Crosshair aktif")
            .setSmallIcon(R.drawable.ic_launcher)
            .setOngoing(true)
            .build()
    }

    private fun showCrosshair() {
        if (crosshairView != null) return
        val prefs = getSharedPreferences("gameturbo", MODE_PRIVATE)
        val style = prefs.getInt("crosshair_style", 0)
        val size = prefs.getInt("crosshair_size", 48)
        val color = prefs.getInt("crosshair_color", 0xFF00FF00.toInt())
        val alpha = prefs.getInt("crosshair_alpha", 200)

        crosshairView = ImageView(this).apply {
            setImageResource(getCrosshairRes(style))
            setColorFilter(color)
            imageAlpha = alpha
            layoutParams = ViewGroup.LayoutParams(size, size)
        }

        val params = WindowManager.LayoutParams(
            size, size,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else
                WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.CENTER

        windowManager.addView(crosshairView, params)
    }

    private fun getCrosshairRes(style: Int): Int {
        return when (style) {
            1 -> R.drawable.crosshair_dot
            2 -> R.drawable.crosshair_cross
            3 -> R.drawable.crosshair_circle
            4 -> R.drawable.crosshair_t
            5 -> R.drawable.crosshair_diamond
            else -> R.drawable.crosshair_default
        }
    }

    override fun onDestroy() {
        crosshairView?.let { windowManager.removeView(it) }
        crosshairView = null
        super.onDestroy()
    }
}
