package com.gameturbo.panel

import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.gameturbo.panel.databinding.ActivityAddGameBinding

class AddGameActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAddGameBinding
    private val prefs by lazy { getSharedPreferences("gameturbo", MODE_PRIVATE) }
    private val selected = mutableSetOf<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAddGameBinding.inflate(layoutInflater)
        setContentView(binding.root)

        selected.addAll(prefs.getStringSet("games", setOf()) ?: setOf())

        val apps = packageManager.getInstalledApplications(PackageManager.GET_META_DATA)
            .filter { (it.flags and ApplicationInfo.FLAG_SYSTEM) == 0 }
            .filter { packageManager.getLaunchIntentForPackage(it.packageName) != null }
            .sortedBy { packageManager.getApplicationLabel(it).toString().lowercase() }

        val adapter = AppSelectAdapter(apps, packageManager, selected) { pkg, checked ->
            if (checked) selected.add(pkg) else selected.remove(pkg)
        }
        binding.rvApps.layoutManager = LinearLayoutManager(this)
        binding.rvApps.adapter = adapter

        binding.btnSave.setOnClickListener {
            prefs.edit().putStringSet("games", selected).apply()
            Toast.makeText(this, "${selected.size} game disimpan", Toast.LENGTH_SHORT).show()
            finish()
        }
    }
}
