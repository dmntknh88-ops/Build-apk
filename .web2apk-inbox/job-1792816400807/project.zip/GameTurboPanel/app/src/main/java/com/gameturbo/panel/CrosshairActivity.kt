package com.gameturbo.panel

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.widget.SeekBar
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.gameturbo.panel.databinding.ActivityCrosshairBinding

class CrosshairActivity : AppCompatActivity() {

    private lateinit var binding: ActivityCrosshairBinding
    private val prefs by lazy { getSharedPreferences("gameturbo", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCrosshairBinding.inflate(layoutInflater)
        setContentView(binding.root)

        loadCurrent()

        binding.rgStyle.setOnCheckedChangeListener { _, checkedId ->
            val style = when (checkedId) {
                R.id.rbDot -> 1
                R.id.rbCross -> 2
                R.id.rbCircle -> 3
                R.id.rbT -> 4
                R.id.rbDiamond -> 5
                else -> 0
            }
            prefs.edit().putInt("crosshair_style", style).apply()
            updatePreview()
        }

        binding.seekSize.setOnSeekBarChangeListener(simpleSeek { p ->
            prefs.edit().putInt("crosshair_size", p + 16).apply()
            updatePreview()
        })

        binding.seekAlpha.setOnSeekBarChangeListener(simpleSeek { p ->
            prefs.edit().putInt("crosshair_alpha", p).apply()
            updatePreview()
        })

        binding.btnColorGreen.setOnClickListener { setColor(0xFF00FF00.toInt()) }
        binding.btnColorRed.setOnClickListener { setColor(0xFFFF0000.toInt()) }
        binding.btnColorCyan.setOnClickListener { setColor(0xFF00FFFF.toInt()) }
        binding.btnColorYellow.setOnClickListener { setColor(0xFFFFFF00.toInt()) }
        binding.btnColorWhite.setOnClickListener { setColor(0xFFFFFFFF.toInt()) }
        binding.btnColorPink.setOnClickListener { setColor(0xFFFF00FF.toInt()) }

        binding.btnApply.setOnClickListener {
            stopService(Intent(this, CrosshairService::class.java))
            startService(Intent(this, CrosshairService::class.java))
            Toast.makeText(this, "Crosshair diterapkan", Toast.LENGTH_SHORT).show()
        }

        binding.btnStop.setOnClickListener {
            stopService(Intent(this, CrosshairService::class.java))
            Toast.makeText(this, "Crosshair dimatikan", Toast.LENGTH_SHORT).show()
        }
    }

    private fun loadCurrent() {
        val style = prefs.getInt("crosshair_style", 0)
        when (style) {
            1 -> binding.rbDot.isChecked = true
            2 -> binding.rbCross.isChecked = true
            3 -> binding.rbCircle.isChecked = true
            4 -> binding.rbT.isChecked = true
            5 -> binding.rbDiamond.isChecked = true
            else -> binding.rbDefault.isChecked = true
        }
        binding.seekSize.progress = prefs.getInt("crosshair_size", 48) - 16
        binding.seekAlpha.progress = prefs.getInt("crosshair_alpha", 200)
        updatePreview()
    }

    private fun setColor(color: Int) {
        prefs.edit().putInt("crosshair_color", color).apply()
        updatePreview()
    }

    private fun updatePreview() {
        val style = prefs.getInt("crosshair_style", 0)
        val size = prefs.getInt("crosshair_size", 48)
        val color = prefs.getInt("crosshair_color", 0xFF00FF00.toInt())
        val alpha = prefs.getInt("crosshair_alpha", 200)
        binding.ivPreview.setImageResource(
            when (style) {
                1 -> R.drawable.crosshair_dot
                2 -> R.drawable.crosshair_cross
                3 -> R.drawable.crosshair_circle
                4 -> R.drawable.crosshair_t
                5 -> R.drawable.crosshair_diamond
                else -> R.drawable.crosshair_default
            }
        )
        binding.ivPreview.setColorFilter(color)
        binding.ivPreview.imageAlpha = alpha
        binding.ivPreview.layoutParams = binding.ivPreview.layoutParams.apply {
            width = size * 2
            height = size * 2
        }
    }

    private fun simpleSeek(block: (Int) -> Unit) = object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(s: SeekBar?, p: Int, f: Boolean) { if (f) block(p) }
        override fun onStartTrackingTouch(s: SeekBar?) {}
        override fun onStopTrackingTouch(s: SeekBar?) {}
    }
}
