package com.gameturbo.panel

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.*
import android.widget.*
import androidx.core.app.NotificationCompat
import java.io.RandomAccessFile


class OverlayService : Service() {

    private lateinit var windowManager: WindowManager
    private var panelView: View? = null
    private var miniView: View? = null
    private val handler = Handler(Looper.getMainLooper())
    private var monitoring = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        startForeground(1, buildNotification())
        showMiniButton()
    }

    private fun buildNotification(): Notification {
        val channelId = "gameturbo_overlay"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId, "Game Turbo Overlay",
                NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
        return NotificationCompat.Builder(this, channelId)
            .setContentTitle("Game Turbo Panel")
            .setContentText("Panel aktif")
            .setSmallIcon(R.drawable.ic_launcher)
            .setOngoing(true)
            .build()
    }

    private fun showMiniButton() {
        if (miniView != null) return
        val inflater = getSystemService(LAYOUT_INFLATER_SERVICE) as LayoutInflater
        miniView = inflater.inflate(R.layout.overlay_mini, null)

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else
                WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.START
        params.x = 20
        params.y = 200

        miniView?.setOnTouchListener(object : View.OnTouchListener {
            private var initialX = 0
            private var initialY = 0
            private var initialTouchX = 0f
            private var initialTouchY = 0f
            private var moved = false

            override fun onTouch(v: View, event: MotionEvent): Boolean {
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        initialX = params.x
                        initialY = params.y
                        initialTouchX = event.rawX
                        initialTouchY = event.rawY
                        moved = false
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (event.rawX - initialTouchX).toInt()
                        val dy = (event.rawY - initialTouchY).toInt()
                        if (Math.abs(dx) > 10 || Math.abs(dy) > 10) moved = true
                        params.x = initialX + dx
                        params.y = initialY + dy
                        windowManager.updateViewLayout(miniView, params)
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        if (!moved) togglePanel()
                        return true
                    }
                }
                return false
            }
        })

        windowManager.addView(miniView, params)
    }

    private fun togglePanel() {
        if (panelView == null) showFullPanel() else hideFullPanel()
    }

    private fun showFullPanel() {
        if (panelView != null) return
        val inflater = getSystemService(LAYOUT_INFLATER_SERVICE) as LayoutInflater
        panelView = inflater.inflate(R.layout.overlay_panel, null)

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else
                WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP

        setupPanelControls(panelView!!)
        windowManager.addView(panelView, params)
        startMonitoring()
    }

    private fun hideFullPanel() {
        panelView?.let {
            windowManager.removeView(it)
            panelView = null
        }
        monitoring = false
    }

    private fun setupPanelControls(view: View) {
        view.findViewById<ImageButton>(R.id.btnClosePanel)?.setOnClickListener {
            hideFullPanel()
        }

        view.findViewById<LinearLayout>(R.id.btnEditKeymap)?.setOnClickListener {
            toast("Keymap editor - buka di app utama")
        }
        view.findViewById<LinearLayout>(R.id.btnGeneralSettings)?.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
        view.findViewById<LinearLayout>(R.id.btnMonitoring)?.setOnClickListener {
            toast("Monitoring aktif")
        }
        view.findViewById<LinearLayout>(R.id.btnCrosshair)?.setOnClickListener {
            startService(Intent(this, CrosshairService::class.java))
            toast("Crosshair ON")
        }
        view.findViewById<LinearLayout>(R.id.btnSensitivity)?.setOnClickListener {
            toast("Sensitivity panel")
        }
        view.findViewById<LinearLayout>(R.id.btnResolution)?.setOnClickListener {
            toast("Skala Resolusi")
        }
        view.findViewById<LinearLayout>(R.id.btnLockOrientation)?.setOnClickListener {
            toast("Orientasi dikunci")
        }
        view.findViewById<LinearLayout>(R.id.btnShowCoord)?.setOnClickListener {
            toast("Koordinat ON")
        }
        view.findViewById<LinearLayout>(R.id.btnShowTouch)?.setOnClickListener {
            toast("Tampilkan sentuhan ON")
        }
        view.findViewById<LinearLayout>(R.id.btnCleanRam)?.setOnClickListener {
            cleanRam()
        }
        view.findViewById<LinearLayout>(R.id.btnBackApp)?.setOnClickListener {
            val i = packageManager.getLaunchIntentForPackage(packageName)
            i?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
        }
        view.findViewById<LinearLayout>(R.id.btnKillApp)?.setOnClickListener {
            hideFullPanel()
            stopSelf()
        }

        // brightness & volume slider
        view.findViewById<SeekBar>(R.id.seekBrightness)?.setOnSeekBarChangeListener(
            object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, f: Boolean) {
                    try {
                        Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS, p)
                    } catch (_: Exception) {}
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            }
        )
    }

    private fun startMonitoring() {
        monitoring = true
        handler.post(object : Runnable {
            override fun run() {
                if (!monitoring || panelView == null) return
                updateStats()
                handler.postDelayed(this, 1000)
            }
        })
    }

    private fun updateStats() {
        try {
            val ram = getRamUsage()
            val cpu = getCpuUsage()
            panelView?.findViewById<TextView>(R.id.tvRam)?.text = "$ram%"
            panelView?.findViewById<TextView>(R.id.tvCpu)?.text = "$cpu%"
            panelView?.findViewById<TextView>(R.id.tvFps)?.text = "60"
        } catch (_: Exception) {}
    }

    private fun getRamUsage(): Int {
        val actManager = getSystemService(ACTIVITY_SERVICE) as ActivityManager
        val memInfo = ActivityManager.MemoryInfo()
        actManager.getMemoryInfo(memInfo)
        val used = memInfo.totalMem - memInfo.availMem
        return ((used * 100) / memInfo.totalMem).toInt()
    }

    private fun getCpuUsage(): Int {
        return try {
            val reader = RandomAccessFile("/proc/stat", "r")
            val load = reader.readLine()
            reader.close()
            val toks = load.split(" +".toRegex()).drop(1)
            val idle = toks[3].toLong()
            val total = toks.take(7).sumOf { it.toLong() }
            (((total - idle) * 100) / total).toInt().coerceIn(0, 99)
        } catch (e: Exception) {
            30
        }
    }

    private fun cleanRam() {
        System.gc()
        toast("RAM dibersihkan")
    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }

    override fun onDestroy() {
        monitoring = false
        panelView?.let { windowManager.removeView(it) }
        miniView?.let { windowManager.removeView(it) }
        panelView = null
        miniView = null
        super.onDestroy()
    }
}
