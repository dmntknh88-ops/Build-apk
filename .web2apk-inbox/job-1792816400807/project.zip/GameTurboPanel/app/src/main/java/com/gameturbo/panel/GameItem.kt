package com.gameturbo.panel

import android.graphics.drawable.Drawable

data class GameItem(
    val packageName: String,
    val label: String,
    val icon: Drawable
)
