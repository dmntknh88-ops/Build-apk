# Game Turbo Panel — Non-Root

Panel overlay style Game Turbo / ROG Phone.

## Fitur
- Floating panel neon (drag + tap buka/tutup)
- Monitoring RAM / FPS / CPU realtime
- Add game dari aplikasi terinstall di HP
- Crosshair 6 style (Default ROG, Dot, Cross, Circle, T, Diamond)
- Atur size, warna, opacity crosshair
- Smooth Screen toggle
- Brightness & volume quick slider
- Clean RAM
- Lock orientation / show touch / show coordinate (flag)
- Pengaturan umum

## Cara build
1. Buka project di Android Studio
2. Sync Gradle
3. Build → Build APK(s) atau Run di HP
4. Izinkan **Display over other apps** saat pertama jalan

## Cara pakai
1. Install APK
2. Buka app → izinkan overlay
3. ADD GAME → centang game (FF dll) → Simpan
4. START PANEL → muncul tombol mini neon
5. Tap tombol mini → panel penuh muncul
6. CROSSHAIR → pilih style → Terapkan
7. Buka game dari list → panel tetap bisa dipanggil

## Catatan non-root
- Tidak inject memory game (aman dari root detect)
- Crosshair & overlay work 100%
- Smooth screen = best effort (tergantung OEM)
- Headshot force / sensix memory write butuh root atau virtual space + GG (lihat chat sebelumnya)

## Package
`com.gameturbo.panel`
