# SENSIX FORTX — Game Turbo Panel (Non-Root)

Native Android (Kotlin). Logo pakai asset SENSIX FORTX (gambar siput racing).

## Fitur
- Logo SENSIX FORTX resmi dari asset lu
- Floating panel neon
- Monitoring RAM / FPS / CPU
- Add game dari HP
- Crosshair 6 style + size / warna / opacity
- Smooth Screen
- Brightness & volume slider
- Clean RAM, orientation, show touch/coord
- Pure Kotlin + AndroidX — no NDK, build aman

## Build anti error
1. Extract zip
2. Buka di Android Studio
3. Sync Gradle
4. Build → Build APK(s)
5. APK: app/build/outputs/apk/debug/app-debug.apk

Min SDK 24 | Target 34 | Kotlin 1.9 | AGP 8.2

Kalau SDK missing: SDK Manager → Android 34 + Build-Tools
Kalau resource error: Clean Project → Rebuild

## Pakai
1. Install APK
2. Izinkan Display over other apps
3. ADD GAME → pilih → Simpan
4. START PANEL → tap tombol mini
5. CROSSHAIR → Terapkan

Package: com.gameturbo.panel
